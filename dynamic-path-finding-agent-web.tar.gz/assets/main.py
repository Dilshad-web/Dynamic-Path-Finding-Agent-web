"""
+= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = +
|         DYNAMIC PATHFINDING AGENT  *  v1.0                  |
|         Built with precision. Designed with intention.       |
+= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = +
"""

import asyncio
import sys
import pygame
from gui.app import PathfindingApp


async def browser_main():
    pygame.init()
    pygame.display.set_caption("* Dynamic Pathfinding Agent")

    app = PathfindingApp()
    await app.run_browser()


def desktop_main():
    pygame.init()
    pygame.display.set_caption("* Dynamic Pathfinding Agent")

    app = PathfindingApp()
    app.run()

    pygame.quit()


if sys.platform == "emscripten":
    asyncio.run(browser_main())
else:
    desktop_main()
